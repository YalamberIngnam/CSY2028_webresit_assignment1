<?php 
session_start();
$connectDatabase = new PDO('mysql:dbname=csy2028_resit_assignmet1;host=localhost','root','');
 ?>